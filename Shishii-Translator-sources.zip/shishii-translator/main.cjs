const {app, BrowserWindow, ipcMain, globalShortcut, dialog, clipboard, Menu, safeStorage} = require('electron');
const {spawn} = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const readline = require('node:readline');
const ROOT = __dirname;
const DATA = process.env.SHISHII_DATA || (path.basename(path.dirname(ROOT))==='resources' ? path.resolve(ROOT,'../../data') : path.join(ROOT,'data'));
app.setPath('userData', path.join(DATA, 'desktop'));
app.setPath('sessionData', path.join(DATA, 'desktop'));
let window, worker, sequence=0, shortcut='', quitting=false;
const pending = new Map();
let initialState=null;
const secretsPath=path.join(DATA,'providers.bin');
function readSecrets(){
  try { return safeStorage.isEncryptionAvailable() && fs.existsSync(secretsPath) ? JSON.parse(safeStorage.decryptString(fs.readFileSync(secretsPath))) : {}; }
  catch { return {}; }
}
function writeSecrets(changes){
  if(!safeStorage.isEncryptionAvailable()) throw Error('Le chiffrement Windows des clés n’est pas disponible sur cette session.');
  fs.mkdirSync(DATA,{recursive:true});
  const next={...readSecrets(),...changes};
  for(const key of Object.keys(next)) if(!next[key]) delete next[key];
  fs.writeFileSync(secretsPath,safeStorage.encryptString(JSON.stringify(next)));
  return Object.fromEntries(Object.keys(next).map(k=>[k,true]));
}
function emit(event,data) { if(window && !window.isDestroyed()) window.webContents.send('service:event',{event,data}); }
function call(op,args={}) {
  return new Promise((resolve,reject)=>{
    if(!worker || !worker.stdin.writable) return reject(Error('Le moteur local est arrêté. Relancez l’application.'));
    const id=++sequence;
    const timer=setTimeout(()=>{pending.delete(id);reject(Error('Le moteur local ne répond pas.'))},30000);
    pending.set(id,{resolve,reject,timer});
    worker.stdin.write(JSON.stringify({id,op,args})+'\n');
  });
}
function registerShortcut(next) {
  if(next===shortcut) return;
  if(!/^(?:(?:Control|Alt|Shift)\+)*(?:F(?:[1-9]|1[0-2])|[A-Z0-9])$/.test(next)) throw Error('Raccourci invalide. Exemple : F8 ou Control+Shift+M.');
  let lastPress=0;
  const ok=globalShortcut.register(next,()=>{
    if(Date.now()-lastPress<450) return;
    lastPress=Date.now();
    call('mic_toggle').catch(e=>emit('error',e.message));
  });
  if(!ok) throw Error('Ce raccourci est déjà utilisé. Choisissez-en un autre.');
  if(shortcut) globalShortcut.unregister(shortcut);
  shortcut=next;
}
function startWorker() {
  fs.mkdirSync(DATA,{recursive:true});
  const log=fs.createWriteStream(path.join(DATA,'engine.log'),{flags:'a'});
  worker=spawn(path.join(ROOT,'runtime','python.exe'),['-u',path.join(ROOT,'backend','service.py')],{
    cwd:ROOT,windowsHide:true,env:{...process.env,SHISHII_DATA:DATA,PYTHONIOENCODING:'utf-8',HF_HUB_OFFLINE:'1'},stdio:['pipe','pipe','pipe']
  });
  worker.stderr.pipe(log);
  readline.createInterface({input:worker.stdout}).on('line',line=>{
    let msg;try {msg=JSON.parse(line)}catch{return;}
    if(msg.id) {
      const p=pending.get(msg.id);
      if(p){clearTimeout(p.timer);pending.delete(msg.id);msg.error?p.reject(Error(msg.error)):p.resolve(msg.result);}
    } else if(msg.event) {
      if(msg.event==='ready'||msg.event==='status') initialState=msg.data;
      if(msg.event==='ready') {
        try {registerShortcut(msg.data.settings.shortcut)} catch(e){emit('error',e.message);}
        call('set_providers',readSecrets()).catch(()=>{});
      }
      emit(msg.event,msg.data);
    }
  });
  worker.on('error',e=>emit('error','Démarrage du moteur impossible : '+e.message));
  worker.on('exit',code=>{
    worker=null;
    for(const p of pending.values()){clearTimeout(p.timer);p.reject(Error('Moteur local arrêté.'));}
    pending.clear();
    if(!quitting) emit('fatal','Le moteur local s’est arrêté ('+code+'). Relancez l’application.');
    log.end();
  });
}
const operations=new Set(['status','history','favorite','delete','clear','devices','voices','speak','stop_speech','vr_test','mic_toggle','translate','install']);
ipcMain.handle('service:call',async(event,op,args={})=>{
  if(event.sender!==window.webContents) throw Error('Accès refusé.');
  if(op==='providers:status') return Object.fromEntries(['deeplKey','elevenLabsKey'].map(k=>[k,!!readSecrets()[k]]));
  if(op==='providers:save') {
    const allowed={};
    for(const key of ['deeplKey','elevenLabsKey']) if(Object.hasOwn(args,key)) allowed[key]=String(args[key]||'').trim();
    const status=writeSecrets(allowed);
    await call('set_providers',readSecrets());
    return status;
  }
  if(op==='settings') {
    const previous=shortcut;
    if(args.shortcut) registerShortcut(args.shortcut);
    try {return await call(op,args)} catch(e){if(previous&&shortcut!==previous)registerShortcut(previous);throw e;}
  }
  if(op==='copy'){clipboard.writeText(String(args.text||''));return true;}
  if(op==='export') {
    const records=await call('history',{favorites:!!args.favorites,limit:1000000});
    const result=await dialog.showSaveDialog(window,{title:'Exporter les traductions',defaultPath:'kikitan-traductions.json',filters:[{name:'Historique JSON',extensions:['json']}]});
    if(result.canceled) return false;
    fs.writeFileSync(result.filePath,JSON.stringify({application:'Shishii Translator',exportedAt:new Date().toISOString(),translations:records},null,2),'utf8');
    return true;
  }
  if(!operations.has(op)) throw Error('Action non autorisée.');
  if(op==='status'&&initialState) return call(op);
  return call(op,args);
});
const single=app.requestSingleInstanceLock();
if(!single) app.quit();
else {
  app.on('second-instance',()=>{if(window){window.restore();window.focus();}});
  app.whenReady().then(()=>{
    Menu.setApplicationMenu(null);
    window=new BrowserWindow({width:1320,height:880,minWidth:1000,minHeight:700,show:process.env.SHISHII_TEST!=='1',title:'Shishii Translator',icon:path.join(ROOT,'ui','shishii.ico'),backgroundColor:'#09090b',
      webPreferences:{preload:path.join(ROOT,'preload.cjs'),contextIsolation:true,nodeIntegration:false,sandbox:true}});
    window.webContents.setWindowOpenHandler(()=>({action:'deny'}));
    window.webContents.on('will-navigate',e=>e.preventDefault());
    window.webContents.session.setPermissionRequestHandler((contents,permission,callback)=>callback(false));
    window.loadFile(path.join(ROOT,'ui/index.html'));
    try {startWorker(); } catch(e) {
      worker=null;
      window.webContents.once('did-finish-load',()=>emit('fatal','Démarrage du moteur impossible : '+e.message));
    }
  });
  app.on('window-all-closed',()=>app.quit());
  app.on('before-quit',()=>{
    quitting=true;
    globalShortcut.unregisterAll();
    if(worker){worker.stdin.end();const child=worker;setTimeout(()=>{if(child.exitCode===null)child.kill();},1500).unref();}
  });
}
