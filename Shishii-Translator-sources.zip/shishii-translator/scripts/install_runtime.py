"""Install wheels into an isolated, relocatable runtime without pip temp directories."""
import hashlib
import json
import sys
import urllib.request
import zipfile
from pathlib import Path
from pip._vendor.packaging.requirements import Requirement
from pip._vendor.packaging.tags import sys_tags
from pip._vendor.packaging.utils import parse_wheel_filename
from pip._vendor.packaging.version import Version, InvalidVersion

root = Path(__file__).resolve().parents[1]
dest = root / 'runtime/Lib/site-packages'
cache = root.parent / 'wheels'
cache.mkdir(exist_ok=True)
tags = list(sys_tags())
ranks = {t: i for i, t in enumerate(tags)}
selected = {}
pending = [Requirement(line) for line in (root/'requirements.txt').read_text().splitlines() if line]
while pending:
    req = pending.pop(0)
    if req.marker and not req.marker.evaluate({'extra': ''}):
        continue
    name = req.name.lower().replace('_', '-')
    if name in selected:
        if selected[name] not in req.specifier:
            raise RuntimeError(f'Conflict: {req} versus {selected[name]}')
        continue
    with urllib.request.urlopen(f'https://pypi.org/pypi/{name}/json') as response:
        package = json.load(response)
    versions = []
    for v in package['releases']:
        try:
            parsed = Version(v)
            if parsed in req.specifier and not parsed.is_prerelease:
                versions.append(parsed)
        except InvalidVersion:
            pass
    versions.sort(reverse=True)
    chosen = None
    for version in versions:
        candidates = []
        for file in package['releases'][str(version)]:
            if not file['filename'].endswith('.whl') or file.get('yanked'):
                continue
            _, _, _, wheel_tags = parse_wheel_filename(file['filename'])
            compatible = [ranks[t] for t in wheel_tags if t in ranks]
            if compatible:
                candidates.append((min(compatible), file))
        if candidates:
            chosen = min(candidates, key=lambda p:p[0])[1]
            break
    if not chosen:
        raise RuntimeError(f'No compatible wheel: {req}')
    selected[name] = str(version)
    print(name, version, flush=True)
    filename = cache / chosen['filename']
    if not filename.exists():
        urllib.request.urlretrieve(chosen['url'], filename)
    if hashlib.sha256(filename.read_bytes()).hexdigest() != chosen['digests']['sha256']:
        raise RuntimeError('Checksum mismatch: '+name)
    with zipfile.ZipFile(filename) as z:
        for member in z.infolist():
            relative = Path(member.filename)
            if relative.is_absolute() or '..' in relative.parts:
                raise RuntimeError('Invalid archive path')
            z.extract(member, dest)
        metadata = next(n for n in z.namelist() if n.endswith('.dist-info/METADATA'))
        for line in z.read(metadata).decode().splitlines():
            if line.startswith('Requires-Dist: '):
                pending.append(Requirement(line[len('Requires-Dist: '):]))
(root/'requirements-lock.json').write_text(json.dumps(selected, indent=2))
print('Runtime ready', flush=True)
