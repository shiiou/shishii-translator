const fs = require('node:fs');
const path = require('node:path');
const {Readable} = require('node:stream');
const {pipeline} = require('node:stream/promises');
async function download(url, dest) {
  fs.mkdirSync(path.dirname(dest), {recursive:true});
  if (fs.existsSync(dest)) return;
  const res = await fetch(url);
  if (!res.ok) throw Error(`${res.status} ${url}`);
  await pipeline(Readable.fromWeb(res.body), fs.createWriteStream(dest+'.part'));
  fs.renameSync(dest+'.part', dest);
  console.log(path.basename(dest), fs.statSync(dest).size);
}
async function main() {
  const root=path.resolve(__dirname,'..');
  await download('https://www.python.org/ftp/python/3.12.10/python-3.12.10-embed-amd64.zip',path.join(root,'../python.zip'));
  await download('https://raw.githubusercontent.com/argosopentech/argospm-index/main/index.json',path.join(root,'models/catalog.json'));
  const catalog=JSON.parse(fs.readFileSync(path.join(root,'models/catalog.json')));
  for(const [from,to] of [['fr','en'],['en','fr']]) {
    const p=catalog.filter(p=>p.from_code===from&&p.to_code===to).at(-1);
    await download(p.links.find(u=>u.startsWith('https:')),path.join(root,`../${from}-${to}.argosmodel`));
  }
  for (const f of ['config.json','model.bin','tokenizer.json','vocabulary.txt']) {
    await download(`https://huggingface.co/Systran/faster-whisper-base/resolve/main/${f}`,path.join(root,'models/whisper-base',f));
  }
}
main().catch(e=>{console.error(e);process.exit(1)});
