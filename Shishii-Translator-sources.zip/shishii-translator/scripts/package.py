"""Build the portable folder and source archive from verified downloaded artifacts."""
import hashlib
import json
import shutil
import zipfile
from pathlib import Path
from pip._vendor.packaging.utils import parse_wheel_filename

ROOT=Path(__file__).resolve().parents[1]
WORK=ROOT.parent
OUTPUT=ROOT.parents[1]/'outputs'
PORTABLE=OUTPUT/'Shishii Translator'
APP=PORTABLE/'resources/app'
PORTABLE.mkdir(parents=True,exist_ok=True)
print('Copying Electron',flush=True)
shutil.copytree(WORK/'electron',PORTABLE,dirs_exist_ok=True)
# Keep the vendor binary unchanged; only the user-facing filename changes.
shutil.copy2(PORTABLE/'electron.exe',PORTABLE/'Shishii Translator.exe')
APP.mkdir(parents=True,exist_ok=True)
for name in ['main.cjs','preload.cjs','package.json','requirements.txt','requirements-lock.json']:
    shutil.copy2(ROOT/name,APP/name)
for name in ['backend','ui','licenses','models']:
    shutil.copytree(ROOT/name,APP/name,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.download'))
for name in ['LISEZ-MOI.md','LICENSE.md']:
    shutil.copy2(ROOT/name,PORTABLE/name)
shutil.copy2(ROOT/'LISEZ-MOI.md',OUTPUT/'Guide-Shishii-Translator.md')
runtime=APP/'runtime'
runtime.mkdir(exist_ok=True)
with zipfile.ZipFile(WORK/'python.zip') as archive:archive.extractall(runtime)
(runtime/'python312._pth').write_text('python312.zip\n.\nLib/site-packages\n../backend\nimport site\n')
lock=json.loads((ROOT/'requirements-lock.json').read_text())
site=runtime/'Lib/site-packages'
manifest={}
for name,version in lock.items():
    wheels=[]
    for file in (WORK/'wheels').glob('*.whl'):
        package,v,_,_=parse_wheel_filename(file.name)
        if str(package).replace('_','-')==name and str(v)==version:wheels.append(file)
    if len(wheels)!=1:raise RuntimeError(f'Wheel selection error: {name} {version}')
    file=wheels[0]
    print('Packing',name,version,flush=True)
    with zipfile.ZipFile(file) as archive:archive.extractall(site)
    manifest[file.name]=hashlib.sha256(file.read_bytes()).hexdigest()
(APP/'dependency-sha256.json').write_text(json.dumps(manifest,indent=2))
print('Source archive',flush=True)
with zipfile.ZipFile(OUTPUT/'Shishii-Translator-sources.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for name in ['main.cjs','preload.cjs','package.json','requirements.txt','requirements-lock.json','README.md','LISEZ-MOI.md','LICENSE.md','index.html','website.css']:
        archive.write(ROOT/name,'shishii-translator/'+name)
    for folder in ['ui','backend','scripts','tests','licenses']:
        for file in (ROOT/folder).rglob('*'):
            if file.is_file() and '__pycache__' not in file.parts:
                archive.write(file,'shishii-translator/'+str(file.relative_to(ROOT)).replace('\\','/'))
print('Portable folder ready:',PORTABLE,flush=True)
