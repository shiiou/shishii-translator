const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('shishii',{
  call:(op,args)=>ipcRenderer.invoke('service:call',op,args),
  onEvent:(callback)=>{
    const listener=(_event,message)=>callback(message);
    ipcRenderer.on('service:event',listener);
    return ()=>ipcRenderer.removeListener('service:event',listener);
  }
});
