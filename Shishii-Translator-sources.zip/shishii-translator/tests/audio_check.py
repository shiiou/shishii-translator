import json
import os
import subprocess
import sys
import time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'backend'))
os.environ['KIKITAN_DATA']=str(ROOT.parent/'audio-test-state')
from service import Service
from vr import VROverlay
s=Service()
try:
    voices=s.get_voices()
    print('Voices:', [v['name'] for v in voices], flush=True)
    wav=ROOT.parent/'speech-test.wav'
    request=dict(action='speak', text='Bonjour. Je suis content de vous rencontrer. Comment allez vous ?',language='fr',voice='',rate=0,output=str(wav))
    result=subprocess.run(s.ps(),input=json.dumps(request),capture_output=True,encoding='utf-8',creationflags=0x08000000,timeout=30)
    assert result.returncode==0, result.stdout+result.stderr
    assert wav.stat().st_size>10000
    start=time.monotonic()
    text=s.engine.transcribe(str(wav),'fr')
    print('Transcript:',text, flush=True)
    assert 'bonjour' in text.lower(), text
    translated=s.engine.translate(text,'fr','en')
    print('Translation:',translated, flush=True)
    print('Seconds:',round(time.monotonic()-start,2), flush=True)
    assert 'hello' in translated.lower(), translated
    image=s.vr.render(translated)
    assert image.exists()
    import openvr
    print('SteamVR installed:',openvr.isRuntimeInstalled(),'HMD connected:',openvr.isHmdPresent(),flush=True)
    print('Audio pipeline OK',flush=True)
finally:s.close()
