import os
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'backend'))
os.environ['SHISHII_DATA'] = str(ROOT.parent/'shishii-test-data')
from core import Store
from service import Service

def check(condition, message):
    if not condition:
        raise AssertionError(message)

store = Store(ROOT.parent/'shishii-test.sqlite3')
settings = store.save_settings({'source':'fr','targets':['en','es','de'],'simultaneous':True,'provider':'deepl','interfaceLanguage':'ja'})
check(settings['targets'] == ['en','es','de'], 'three targets were not saved')
try:
    store.save_settings({'targets':['en','en']})
    raise AssertionError('duplicate target accepted')
except ValueError:
    pass

service = Service()
events=[]
import service as service_module
old_emit=service_module.emit
service_module.emit=lambda event, data: events.append((event,data))
try:
    service.providers={'deeplKey':'not-used-by-test'}
    service.deepl_translate=lambda text, source, targets, plan: {target:f'{text} → {target}' for target in targets}
    config=service.store.save_settings({'source':'fr','targets':['en','es','de'],'simultaneous':True,'provider':'deepl','tts':False})
    service.translate('Bonjour Shishii', config, time.monotonic())
    result=next(data for event,data in events if event=='translation')
    check(set(result['translations']) == {'en','es','de'}, 'three translations missing')
    history=service.store.history()
    check(history[0]['translations']['de'].endswith('de'), 'multi-language history did not persist')
    events.clear()
    config=service.store.save_settings({'simultaneous':False})
    service.translate('Bonjour Shishii', config, time.monotonic())
    result=next(data for event,data in events if event=='translation')
    check(set(result['translations']) == {'en'}, 'single-language mode did not stay single')
    local=service.engine.translate('Bonjour, comment allez-vous ?', 'fr','en')
    check('Hello' in local and '▁' not in local, 'local fallback failed')
    print('Shishii tests OK')
finally:
    service_module.emit=old_emit
    service.close()
