"""Local browser preview. It never calls external AI providers."""
import json
import os
import sys
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'backend'))
os.environ['SHISHII_DATA']=str(ROOT.parent/'preview-data')
import service

backend=service.Service()
backend.providers={'deeplKey':'preview','elevenLabsKey':'preview'}
backend.deepl_translate=lambda text, source, targets, plan: {target:f'{text} [{target.upper()}]' for target in targets}
service.emit=lambda event,data:None
bridge="""window.shishii={call:async(op,args={})=>{const r=await fetch('/call',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({op,args})});const j=await r.json();if(j.error)throw Error(j.error);return j.result;},onEvent:()=>()=>{}};"""

class Handler(BaseHTTPRequestHandler):
    def respond(self,data,mime='application/json'):
        if isinstance(data,(dict,list)):data=json.dumps(data,ensure_ascii=False).encode()
        elif isinstance(data,str):data=data.encode()
        self.send_response(200);self.send_header('Content-Type',mime+'; charset=utf-8');self.end_headers();self.wfile.write(data)
    def do_GET(self):
        if self.path=='/bridge.js':return self.respond(bridge,'text/javascript')
        files={'/':'index.html','/app.js':'app.js','/style.css':'style.css','/shishii-logo.png':'shishii-logo.png'}
        if self.path not in files:self.send_error(404);return
        file=ROOT/'ui'/files[self.path]
        if self.path=='/shishii-logo.png':return self.respond(file.read_bytes(),'image/png')
        text=file.read_text(encoding='utf-8')
        if self.path=='/':text=text.replace("connect-src 'none'", "connect-src 'self'").replace('<script src="app.js">','<script src="bridge.js"></script><script src="app.js">')
        return self.respond(text,{'/':'text/html','/app.js':'text/javascript','/style.css':'text/css'}[self.path])
    def do_POST(self):
        data=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        try:
            if data['op']=='providers:status': return self.respond({'result':{'deepl':True,'elevenLabs':True}})
            if data['op'] in ('providers:save','copy','export','speak','stop_speech','vr_test','mic_toggle','devices','voices'): return self.respond({'result':[] if data['op'] in ('devices','voices') else True})
            self.respond({'result':backend.dispatch(data['op'],data.get('args',{}))})
        except Exception as exc:self.respond({'error':str(exc)})
    def log_message(self,*args):pass

try:ThreadingHTTPServer(('127.0.0.1',8766),Handler).serve_forever()
finally:backend.close()
