import json
import socket
import sys
import tempfile
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'backend'))
from core import LocalEngine, Store, osc_packet, send_osc

class CoreTests(unittest.TestCase):
    def setUp(self):
        # Avoid restrictive tempfile ACLs in the execution sandbox.
        self.folder = ROOT.parent / 'test-state' / str(time.time_ns())
        self.folder.mkdir(parents=True)
        self.store = Store(self.folder/'history.sqlite3')

    def entry(self, text='Bonjour'):
        return dict(timestamp=time.time(), source='fr', target='en', original=text,
                    translated='Hello', duration=.1)

    def test_history_persists_and_clear_keeps_favorites(self):
        first=self.store.add(self.entry())
        self.store.add(self.entry('Autre phrase'))
        self.store.favorite(first['id'], True)
        second=Store(self.folder/'history.sqlite3')
        second.clear()
        self.assertEqual(len(second.history()), 1)
        self.assertEqual(second.history()[0]['id'], first['id'])
        second.delete(first['id'])
        self.assertEqual(second.history(), [])

    def test_no_history_mode_and_settings_validation(self):
        self.store.save_settings({'keepHistory':False})
        self.assertIsNone(self.store.add(self.entry())['id'])
        self.assertEqual(self.store.history(), [])
        with self.assertRaises(ValueError): self.store.save_settings({'oscPort':99999})
        with self.assertRaises(ValueError): self.store.save_settings({'target':'invalid'})

    def test_search_treats_quotes_as_data(self):
        self.store.add(self.entry("L'ami de Robert"))
        self.assertEqual(len(self.store.history("L'ami")),1)
        self.assertEqual(self.store.history("'; DROP TABLE history; --"),[])

    def test_osc_unicode_limit_and_udp_delivery(self):
        packet=osc_packet('🙂'*200)
        self.assertEqual(len(packet)%4,0)
        parts=packet.split(b'\0')
        self.assertEqual(parts[0],b'/chatbox/input')
        self.assertIn(b',sTF',parts)
        self.assertEqual(len(('🙂'*72).encode('utf-16-le')),288)
        self.assertIn(('🙂'*72).encode(),packet)
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as receiver:
            receiver.bind(('127.0.0.1',0));receiver.settimeout(2)
            send_osc('Bonjour !',receiver.getsockname()[1])
            data,_=receiver.recvfrom(2048)
            self.assertEqual(data,osc_packet('Bonjour !'))

    def test_real_local_translation_and_missing_pair(self):
        engine=LocalEngine([ROOT/'models'])
        english=engine.translate('Bonjour, comment allez-vous ?', 'fr','en')
        french=engine.translate('Nice to meet you. I am learning French.', 'en','fr')
        self.assertIn('Hello',english)
        self.assertIn('français',french)
        self.assertNotIn('▁',english+french)
        self.assertEqual(engine.translate('Bonjour','fr','fr'),'Bonjour')
        with self.assertRaises(ValueError):engine.route('fr','ja')

if __name__=='__main__':unittest.main(verbosity=2)
