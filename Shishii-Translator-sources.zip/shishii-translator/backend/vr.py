"""SteamVR overlay; placement adapted from Kikitan OpenVROverlay.cs (MIT)."""
import os
import queue
import threading
import time
from pathlib import Path

class VROverlay:
    def __init__(self, folder, emit):
        self.folder = Path(folder)
        self.emit = emit
        self.commands = queue.Queue()
        self.thread = threading.Thread(target=self.run, daemon=True)
        self.thread.start()

    def show(self, text, settings):
        self.commands.put(('show', text, dict(settings)))

    def hide(self):
        self.commands.put(('hide', '', {}))

    def close(self):
        self.commands.put(('close', '', {}))
        self.thread.join(timeout=3)

    def render(self, text):
        from PIL import Image, ImageDraw, ImageFont
        font_dir = Path(os.environ.get('WINDIR', 'C:/Windows')) / 'Fonts'
        # Segoe UI for European scripts; Yu Gothic or Microsoft YaHei for CJK when installed.
        candidates = ['msyh.ttc', 'YuGothM.ttc', 'malgun.ttf', 'segoeui.ttf'] if any(ord(c) > 0x2E80 for c in text) else ['segoeui.ttf']
        font_path = next((font_dir / f for f in candidates if (font_dir / f).exists()), None)
        font = ImageFont.truetype(str(font_path), 36) if font_path else ImageFont.load_default(size=36)
        title_font = ImageFont.truetype(str(font_dir / 'segoeui.ttf'), 19)
        probe = ImageDraw.Draw(Image.new('RGBA', (1, 1)))
        lines, current = [], ''
        for char in text[:2000]:
            if char == '\n' or probe.textlength(current + char, font=font) > 914:
                lines.append(current.strip())
                current = '' if char == '\n' else char
            else:
                current += char
        if current:
            lines.append(current.strip())
        if len(lines) > 7:
            lines = lines[:7]
            lines[-1] = lines[-1][:-1] + '…'
        img = Image.new('RGBA', (1024, 98 + 51 * max(1, len(lines))), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.rounded_rectangle((1, 1, img.width-1, img.height-1), radius=24, fill=(18, 22, 30, 237), outline=(79, 111, 108, 240), width=2)
        draw.text((48, 22), 'KIKITAN LOCAL', font=title_font, fill=(143, 223, 202))
        for i, line in enumerate(lines):
            draw.text((48, 62+i*51), line, font=font, fill=(245, 248, 251))
        filename = self.folder / 'subtitle.png'
        img.save(filename)
        return filename

    def run(self):
        vr = handle = None
        deadline = 0
        while True:
            try:
                action, text, settings = self.commands.get(timeout=.15)
            except queue.Empty:
                if vr and deadline and time.monotonic() > deadline:
                    try:
                        vr.hideOverlay(handle)
                    except Exception:
                        vr = handle = None
                    deadline = 0
                continue
            if action == 'close':
                break
            try:
                if action == 'hide':
                    if vr:
                        vr.hideOverlay(handle)
                    continue
                import openvr
                if vr is None:
                    openvr.init(openvr.VRApplication_Overlay)
                    vr = openvr.VROverlay()
                    handle = vr.createOverlay('kikitan.local.subtitles', 'Kikitan Local')
                matrix = openvr.HmdMatrix34_t()
                for i in range(3):
                    matrix.m[i][i] = 1
                matrix.m[1][3] = settings['vrY']
                matrix.m[2][3] = -settings['vrDistance']
                vr.setOverlayTransformTrackedDeviceRelative(handle, openvr.k_unTrackedDeviceIndex_Hmd, matrix)
                vr.setOverlayWidthInMeters(handle, settings['vrWidth'])
                vr.setOverlayAlpha(handle, 1)
                vr.setOverlayFromFile(handle, str(self.render(text)))
                vr.showOverlay(handle)
                deadline = time.monotonic() + settings['vrSeconds']
                self.emit('vr', {'connected': True, 'message': 'Sous-titres envoyés à SteamVR'})
            except Exception as exc:
                self.emit('vr', {'connected': False, 'message': 'SteamVR indisponible : démarrez SteamVR et connectez votre casque.', 'detail': str(exc)})
                if vr:
                    try:
                        vr.destroyOverlay(handle)
                    except Exception:
                        pass
                try:
                    import openvr
                    openvr.shutdown()
                except Exception:
                    pass
                vr = handle = None
        if vr:
            try:
                vr.destroyOverlay(handle)
                import openvr
                openvr.shutdown()
            except Exception:
                pass
