$ErrorActionPreference = 'Stop'
[Console]::InputEncoding = [System.Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
try {
    Add-Type -AssemblyName System.Speech
    $synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
    $request = [Console]::In.ReadToEnd() | ConvertFrom-Json
    if ($request.action -eq 'voices') {
        $voices = @($synth.GetInstalledVoices() | ForEach-Object {
            @{name=$_.VoiceInfo.Name; language=$_.VoiceInfo.Culture.Name; enabled=$_.Enabled}
        })
        ConvertTo-Json -InputObject $voices -Compress
    } else {
        if ($request.voice) { $synth.SelectVoice([string]$request.voice) }
        elseif ($request.language) {
            $voice = $synth.GetInstalledVoices() | Where-Object { $_.Enabled -and $_.VoiceInfo.Culture.TwoLetterISOLanguageName -eq $request.language } | Select-Object -First 1
            if (-not $voice) { throw "Aucune voix Windows pour cette langue. Installez une voix dans les parametres Windows ou choisissez une voix." }
            $synth.SelectVoice($voice.VoiceInfo.Name)
        }
        $synth.Rate = [int]$request.rate
        if ($request.output) { $synth.SetOutputToWaveFile([string]$request.output) }
        $synth.Speak([string]$request.text)
        $synth.Dispose()
        '{"ok":true}'
    }
} catch {
    @{error=$_.Exception.Message} | ConvertTo-Json -Compress
    exit 1
}
