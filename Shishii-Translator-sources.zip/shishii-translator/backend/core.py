"""Local storage, model inference and VRChat OSC."""
import json
import os
import re
import socket
import sqlite3
import threading
import time
from pathlib import Path

LANGUAGES = {'fr': 'Français', 'en': 'Anglais', 'ja': 'Japonais', 'de': 'Allemand',
             'es': 'Espagnol', 'it': 'Italien', 'ko': 'Coréen', 'zh': 'Chinois',
             'pt': 'Portugais', 'ru': 'Russe'}
DEFAULTS = dict(source='fr', targets=['en', 'es', 'de'], simultaneous=False, provider='deepl', deeplPlan='free',
                interfaceLanguage='fr', device=None, tts=False, ttsProvider='elevenlabs',
                elevenVoiceId='', voice='', rate=0, osc=False, oscPort=9000, vr=False,
                vrWidth=1.1, vrY=-0.35, vrDistance=1.5, vrSeconds=8, shortcut='F8', keepHistory=True)

class Store:
    def __init__(self, path):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.path = str(path)
        with self.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS settings (id INTEGER PRIMARY KEY, data TEXT NOT NULL)')
            db.execute('CREATE TABLE IF NOT EXISTS history (id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp REAL NOT NULL, source TEXT, target TEXT, original TEXT, translated TEXT, duration REAL, favorite INTEGER DEFAULT 0, translations TEXT, provider TEXT)')
            columns={row[1] for row in db.execute('PRAGMA table_info(history)')}
            if 'translations' not in columns: db.execute('ALTER TABLE history ADD COLUMN translations TEXT')
            if 'provider' not in columns: db.execute('ALTER TABLE history ADD COLUMN provider TEXT')

    def connect(self):
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        return db

    def settings(self):
        with self.connect() as db:
            row = db.execute('SELECT data FROM settings WHERE id=1').fetchone()
        return {**DEFAULTS, **(json.loads(row[0]) if row else {})}

    def save_settings(self, changes):
        s = {**self.settings(), **{k: v for k, v in changes.items() if k in DEFAULTS}}
        targets=s.get('targets', [])
        if not isinstance(targets,list) or not 1 <= len(targets) <= 3 or len(set(targets)) != len(targets):
            raise ValueError('Choisissez entre une et trois langues de traduction différentes.')
        if s['source'] not in LANGUAGES or any(target not in LANGUAGES or target == s['source'] for target in targets):
            raise ValueError('Langue non prise en charge.')
        if s['provider'] not in ('deepl','local') or s['deeplPlan'] not in ('free','pro') or s['ttsProvider'] not in ('elevenlabs','windows'):
            raise ValueError('Fournisseur invalide.')
        if s['interfaceLanguage'] not in LANGUAGES:
            raise ValueError('Langue de l’interface invalide.')
        for key in ('simultaneous', 'tts', 'osc', 'vr', 'keepHistory'):
            if not isinstance(s[key], bool):
                raise ValueError('Réglage invalide : ' + key)
        for key, low, high in [('rate', -5, 5), ('oscPort', 1024, 65535), ('vrWidth', .3, 3), ('vrY', -2, 1), ('vrDistance', .5, 4), ('vrSeconds', 2, 30)]:
            if not isinstance(s[key], (int, float)) or not low <= s[key] <= high:
                raise ValueError('Valeur hors limites : ' + key)
        with self.connect() as db:
            db.execute('INSERT OR REPLACE INTO settings VALUES (1, ?)', (json.dumps(s),))
        return s

    def add(self, entry):
        if not self.settings()['keepHistory']:
            return {**entry, 'id': None, 'favorite': False}
        with self.connect() as db:
            cur = db.execute('INSERT INTO history (timestamp,source,target,original,translated,duration,translations,provider) VALUES (?,?,?,?,?,?,?,?)',
                             tuple(entry[k] for k in ('timestamp', 'source', 'target', 'original', 'translated', 'duration')) + (json.dumps(entry.get('translations',{}),ensure_ascii=False),entry.get('provider','local')))
        return {**entry, 'id': cur.lastrowid, 'favorite': False}

    def history(self, query='', favorites=False, limit=500):
        with self.connect() as db:
            items=[dict(r) for r in db.execute('SELECT * FROM history WHERE (original LIKE ? OR translated LIKE ?) AND (?=0 OR favorite=1) ORDER BY id DESC LIMIT ?',
                    ('%' + query + '%', '%' + query + '%', int(favorites), limit))]
        for item in items:
            try: item['translations']=json.loads(item.get('translations') or '{}')
            except ValueError: item['translations']={}
        return items

    def favorite(self, item_id, value):
        with self.connect() as db:
            db.execute('UPDATE history SET favorite=? WHERE id=?', (int(bool(value)), int(item_id)))

    def delete(self, item_id):
        with self.connect() as db:
            db.execute('DELETE FROM history WHERE id=?', (int(item_id),))

    def clear(self):
        with self.connect() as db:
            db.execute('DELETE FROM history WHERE favorite=0')

def osc_string(value):
    data = value.encode('utf-8') + b'\0'
    return data + b'\0' * (-len(data) % 4)

def osc_packet(text):
    # Same chatbox endpoint as Kikitan's Chatbox.cs. True: immediate; False: no sound.
    text = text.replace('\0', '').encode('utf-16-le')[:288].decode('utf-16-le', errors='ignore')
    return osc_string('/chatbox/input') + osc_string(',sTF') + osc_string(text)

def send_osc(text, port):
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as client:
        client.sendto(osc_packet(text), ('127.0.0.1', int(port)))

class LocalEngine:
    def __init__(self, model_roots):
        self.roots = [Path(p) for p in model_roots]
        self.translators = {}
        self.whisper = None
        self.lock = threading.Lock()

    def packages(self):
        found = {}
        for root in self.roots:
            for f in root.glob('translate-*/metadata.json'):
                try:
                    meta = json.loads(f.read_text(encoding='utf-8'))
                    if (f.parent / 'model/model.bin').exists() and (f.parent / 'sentencepiece.model').exists():
                        found[(meta['from_code'], meta['to_code'])] = f.parent
                except (ValueError, KeyError, OSError):
                    continue
        return found

    def route(self, source, target):
        if source == target:
            return []
        packages = self.packages()
        if (source, target) in packages:
            return [(source, target)]
        if (source, 'en') in packages and ('en', target) in packages:
            return [(source, 'en'), ('en', target)]
        raise ValueError('Modèle manquant. Ouvrez « Modèles locaux » et installez cette paire de langues.')

    def translate(self, text, source, target):
        import ctranslate2
        import sentencepiece
        with self.lock:
            for pair in self.route(source, target):
                if pair not in self.translators:
                    p = self.packages()[pair]
                    self.translators[pair] = (ctranslate2.Translator(str(p / 'model'), device='cpu', compute_type='int8', intra_threads=max(1, min(4, os.cpu_count() or 2))),
                                              sentencepiece.SentencePieceProcessor(model_file=str(p / 'sentencepiece.model')))
                translator, tokenizer = self.translators[pair]
                chunks = []
                for sentence in re.split(r'(?<=[.!?。！？])\s+|\n+', text.strip()):
                    tokens = tokenizer.encode(sentence, out_type=str)
                    chunks.extend(tokens[i:i+120] for i in range(0, len(tokens), 120))
                results = translator.translate_batch(chunks, beam_size=4, max_decoding_length=256, replace_unknowns=True)
                text = ' '.join(tokenizer.decode(r.hypotheses[0]).replace('▁', ' ').strip() for r in results)
        return text.strip()

    def whisper_path(self):
        for root in reversed(self.roots):
            p = root / 'whisper-base'
            if all((p / f).exists() for f in ('model.bin', 'config.json', 'tokenizer.json', 'vocabulary.txt')):
                return p
        return None

    def transcribe(self, audio, language):
        from faster_whisper import WhisperModel
        if self.whisper is None:
            p = self.whisper_path()
            if not p:
                raise ValueError('Le modèle vocal Whisper Base est absent.')
            self.whisper = WhisperModel(str(p), device='cpu', compute_type='int8', cpu_threads=max(1, min(4, os.cpu_count() or 2)), local_files_only=True)
        segments, _ = self.whisper.transcribe(audio, language=language, beam_size=3, vad_filter=True,
                                             condition_on_previous_text=False)
        return ' '.join(s.text.strip() for s in segments).strip()
