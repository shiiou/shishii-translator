import concurrent.futures
import json
import os
import queue
import subprocess
import sys
import threading
import time
import traceback
import urllib.request
import urllib.error
import urllib.parse
import zipfile
from pathlib import Path
from core import DEFAULTS, LANGUAGES, LocalEngine, Store, send_osc
from vr import VROverlay

os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['HF_HUB_DISABLE_TELEMETRY'] = '1'
APP = Path(__file__).resolve().parents[1]
DATA = Path(os.environ.get('SHISHII_DATA', APP / 'data'))
DATA.mkdir(parents=True, exist_ok=True)
PRINT_LOCK = threading.Lock()

def output(message):
    with PRINT_LOCK:
        print(json.dumps(message, ensure_ascii=False), flush=True)

def emit(event, data):
    output({'event': event, 'data': data})

class Service:
    def __init__(self):
        self.store = Store(DATA / 'shishii.sqlite3')
        self.engine = LocalEngine([APP / 'models', DATA / 'models'])
        self.vr = VROverlay(DATA, emit)
        self.pool = concurrent.futures.ThreadPoolExecutor(max_workers=1)
        self.mic_lock = threading.Lock()
        self.busy_lock = threading.Lock()
        self.busy = False
        self.stream = None
        self.frames = []
        self.record_settings = None
        self.timer = None
        self.speech = None
        self.speech_lock = threading.Lock()
        self.closed = False
        self.last_level = 0
        self.catalog = json.loads((APP / 'models/catalog.json').read_text(encoding='utf-8'))
        self.providers = {}

    def status(self):
        settings = self.store.settings()
        targets = settings['targets'] if settings['simultaneous'] else settings['targets'][:1]
        ready = bool(self.providers.get('deeplKey')) if settings['provider']=='deepl' else all(
            self.can_translate_locally(settings['source'], target) for target in targets)
        return dict(settings=settings, languages=LANGUAGES, providers=self.provider_status(),
                    pairs=[{'source': a, 'target': b} for a, b in self.engine.packages()],
                    whisper=bool(self.engine.whisper_path()), translationReady=ready,
                    recording=self.stream is not None, busy=self.busy)

    def dispatch(self, op, args):
        if op == 'status':
            return self.status()
        if op == 'set_providers':
            self.providers={key:str(args.get(key,'')).strip() for key in ('deeplKey','elevenLabsKey') if args.get(key)}
            return self.provider_status()
        if op == 'settings':
            s = self.store.save_settings(args)
            if not s['vr']:
                self.vr.hide()
            if not s['tts']:
                self.stop_speech()
            return self.status()
        if op == 'history':
            return self.store.history(str(args.get('query', ''))[:500], bool(args.get('favorites')), int(args.get('limit', 500)))
        if op == 'favorite':
            self.store.favorite(args['id'], args['value'])
            return True
        if op == 'delete':
            self.store.delete(args['id'])
            return True
        if op == 'clear':
            self.store.clear()
            return True
        if op == 'devices':
            import sounddevice as sd
            return [{'id': i, 'name': d['name'], 'api': sd.query_hostapis(d['hostapi'])['name']}
                    for i, d in enumerate(sd.query_devices()) if d['max_input_channels'] > 0]
        if op == 'voices':
            return self.get_voices()
        if op == 'speak':
            self.speak(str(args.get('text', ''))[:2000], args.get('language', self.store.settings()['targets'][0]))
            return True
        if op == 'stop_speech':
            self.stop_speech()
            return True
        if op == 'vr_test':
            self.vr.show('Bonjour ! Vos sous-titres apparaîtront ici.', self.store.settings())
            return True
        if op == 'mic_toggle':
            return self.toggle_mic()
        if op == 'translate':
            text = str(args.get('text', '')).strip()
            if not text or len(text) > 2000:
                raise ValueError('Saisissez entre 1 et 2 000 caractères.')
            return self.submit(lambda: self.translate(text, self.store.settings()))
        if op == 'install':
            source, target = args.get('source'), args.get('target')
            if source not in LANGUAGES or target not in LANGUAGES or source == target:
                raise ValueError('Choisissez deux langues différentes.')
            return self.submit(lambda: self.install(source, target))
        raise ValueError('Action inconnue.')

    def provider_status(self):
        return {'deepl': bool(self.providers.get('deeplKey')), 'elevenlabs': bool(self.providers.get('elevenLabsKey'))}

    def can_translate_locally(self, source, target):
        try:
            self.engine.route(source, target)
            return True
        except ValueError:
            return False

    def submit(self, job):
        with self.busy_lock:
            if self.busy:
                raise ValueError('Une opération est déjà en cours.')
            self.busy = True
        emit('busy', True)
        def run():
            try:
                job()
            except Exception as exc:
                emit('error', str(exc))
                traceback.print_exc(file=sys.stderr)
            finally:
                with self.busy_lock:
                    self.busy = False
                emit('busy', False)
                emit('status', self.status())
        self.pool.submit(run)
        return {'accepted': True}

    def translate(self, text, settings, started=None):
        started = started or time.monotonic()
        targets = settings['targets'] if settings['simultaneous'] else settings['targets'][:1]
        emit('phase', 'Traduction simultanée…' if settings['simultaneous'] else 'Traduction…')
        if settings['provider']=='deepl':
            translations=self.deepl_translate(text, settings['source'], targets, settings['deeplPlan'])
        else:
            translations={target:self.engine.translate(text, settings['source'], target) for target in targets}
        if not translations or not all(translations.values()):
            raise ValueError('Aucune traduction produite. Essayez une phrase plus courte.')
        primary_target=targets[0]
        translated=translations[primary_target]
        entry = self.store.add(dict(timestamp=time.time(), source=settings['source'], target=primary_target,
                                    original=text, translated=translated, translations=translations,
                                    provider=settings['provider'], duration=round(time.monotonic()-started, 2)))
        emit('translation', entry)
        if settings['osc']:
            try:
                send_osc(translated, settings['oscPort'])
                emit('osc', 'Message envoyé au port local ' + str(settings['oscPort']) + ' (réception VRChat non vérifiable).')
            except Exception as exc:
                emit('error', 'Envoi VRChat : '+str(exc))
        if settings['vr']:
            self.vr.show(translated, settings)
        if settings['tts']:
            self.speak(translated, primary_target)

    def deepl_translate(self, text, source, targets, plan):
        key=self.providers.get('deeplKey')
        if not key:
            raise ValueError('Ajoutez votre clé DeepL dans Connexions avant de choisir DeepL.')
        endpoint='https://api.deepl.com/v2/translate' if plan=='pro' else 'https://api-free.deepl.com/v2/translate'
        codes={'zh':'ZH','pt':'PT-BR','en':'EN-US'}
        response={}
        for target in targets:
            body=urllib.parse.urlencode({'text':text,'source_lang':codes.get(source,source.upper()),'target_lang':codes.get(target,target.upper())}).encode('utf-8')
            request=urllib.request.Request(endpoint,data=body,headers={'Authorization':'DeepL-Auth-Key '+key,'Content-Type':'application/x-www-form-urlencoded'},method='POST')
            try:
                with urllib.request.urlopen(request,timeout=25) as result:
                    response[target]=json.loads(result.read().decode('utf-8'))['translations'][0]['text']
            except urllib.error.HTTPError as exc:
                if exc.code in (401,403): raise ValueError('DeepL a refusé la clé. Vérifiez-la dans Connexions.')
                if exc.code==456: raise ValueError('Le quota DeepL est épuisé.')
                raise ValueError(f'Erreur DeepL ({exc.code}). Réessayez plus tard.')
            except (urllib.error.URLError,TimeoutError):
                raise ValueError('DeepL est inaccessible. Vérifiez votre connexion Internet.')
        return response

    def toggle_mic(self, stop_only=False):
        import numpy as np
        import sounddevice as sd
        with self.mic_lock:
            if stop_only and self.stream is None:
                return {'recording': False}
            if self.stream is not None:
                stream, self.stream = self.stream, None
                if self.timer:
                    self.timer.cancel()
                stream.stop()
                stream.close()
                audio = np.concatenate(self.frames) if self.frames else np.zeros(0, dtype=np.float32)
                self.frames = []
                settings = self.record_settings
                emit('recording', False)
                def process():
                    if len(audio) < 3200 or float(np.sqrt(np.mean(audio**2))) < .002:
                        raise ValueError('Aucune parole audible. Vérifiez votre microphone et recommencez.')
                    start = time.monotonic()
                    emit('phase', 'Reconnaissance vocale locale…')
                    text = self.engine.transcribe(audio, settings['source'])
                    if not text:
                        raise ValueError('Aucune parole reconnue.')
                    emit('transcript', text)
                    self.translate(text, settings, start)
                self.submit(process)
                return {'recording': False}
            if self.busy:
                raise ValueError('Attendez la fin du traitement pour activer le microphone.')
            settings = self.store.settings()
            targets = settings['targets'] if settings['simultaneous'] else settings['targets'][:1]
            if settings['provider']=='local':
                for target in targets:
                    self.engine.route(settings['source'], target)
            elif not self.providers.get('deeplKey'):
                raise ValueError('Ajoutez votre clé DeepL dans Connexions avant de démarrer la traduction.')
            if not self.engine.whisper_path():
                raise ValueError('Le modèle vocal local est absent.')
            self.stop_speech()
            self.frames = []
            self.record_settings = settings
            def callback(indata, frames, timing, status):
                self.frames.append(indata[:, 0].copy())
                now = time.monotonic()
                if now - self.last_level > .1:
                    self.last_level = now
                    emit('level', min(1, float(np.sqrt(np.mean(indata**2))) * 8))
            stream = sd.InputStream(samplerate=16000, channels=1, dtype='float32', device=settings['device'], callback=callback)
            try:
                stream.start()
            except Exception:
                stream.close()
                raise
            self.stream = stream
            emit('recording', True)
            self.timer = threading.Timer(30, self.auto_stop)
            self.timer.daemon = True
            self.timer.start()
            return {'recording': True}

    def auto_stop(self):
        if self.stream is not None:
            try:
                self.toggle_mic(stop_only=True)
            except Exception as exc:
                emit('error', str(exc))

    def ps(self):
        return [str(Path(os.environ.get('WINDIR', 'C:/Windows')) / 'System32/WindowsPowerShell/v1.0/powershell.exe'),
                '-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', str(APP/'backend/speech.ps1')]

    def get_voices(self):
        p = subprocess.run(self.ps(), input=json.dumps({'action':'voices'}), capture_output=True,
                           encoding='utf-8', timeout=20, creationflags=0x08000000)
        if p.returncode:
            raise ValueError('Voix Windows indisponibles : '+p.stdout.strip())
        return json.loads(p.stdout.lstrip('\ufeff') or '[]')

    def stop_speech(self):
        with self.speech_lock:
            if self.speech and self.speech.poll() is None:
                self.speech.terminate()
            self.speech = None

    def speak(self, text, language):
        self.stop_speech()
        s = self.store.settings()
        if s['ttsProvider']=='elevenlabs':
            return self.elevenlabs_speak(text, language, s)
        def run():
            try:
                with self.speech_lock:
                    if self.closed:
                        return
                    process = subprocess.Popen(self.ps(), stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                               encoding='utf-8', creationflags=0x08000000)
                    self.speech = process
                stdout, stderr = process.communicate(json.dumps(dict(action='speak', text=text, language=language, voice=s['voice'], rate=s['rate'])))
                with self.speech_lock:
                    current = self.speech is process
                    if current:
                        self.speech = None
                if current and process.returncode:
                    emit('error', 'Lecture vocale : '+ (stdout.strip() or stderr.strip()))
            except Exception as exc:
                emit('error', 'Lecture vocale : '+str(exc))
        threading.Thread(target=run, daemon=True).start()

    def elevenlabs_speak(self, text, language, settings):
        key=self.providers.get('elevenLabsKey')
        voice=settings.get('elevenVoiceId','').strip()
        if not key:
            emit('error', 'Ajoutez une clé ElevenLabs dans Connexions, ou choisissez les voix Windows.')
            return
        if not voice:
            emit('error', 'Indiquez un identifiant de voix ElevenLabs dans Connexions.')
            return
        def run():
            try:
                payload=json.dumps({'text':text,'model_id':'eleven_multilingual_v2','voice_settings':{'stability':0.5,'similarity_boost':0.75}}).encode('utf-8')
                request=urllib.request.Request('https://api.elevenlabs.io/v1/text-to-speech/'+urllib.parse.quote(voice)+'/stream?output_format=mp3_44100_128',data=payload,headers={'xi-api-key':key,'Content-Type':'application/json','Accept':'audio/mpeg'},method='POST')
                with urllib.request.urlopen(request,timeout=45) as response:
                    audio=response.read()
                if len(audio)<128: raise ValueError('ElevenLabs n’a pas retourné de fichier audio.')
                destination=DATA/'elevenlabs-preview.mp3'
                destination.write_bytes(audio)
                emit('eleven_audio', {'path':str(destination), 'language':language})
            except urllib.error.HTTPError as exc:
                if exc.code in (401,403): emit('error','ElevenLabs a refusé la clé ou la voix sélectionnée.')
                elif exc.code==429: emit('error','La limite ElevenLabs est atteinte. Réessayez plus tard.')
                else: emit('error',f'Erreur ElevenLabs ({exc.code}).')
            except (urllib.error.URLError,TimeoutError):
                emit('error','ElevenLabs est inaccessible. Vérifiez votre connexion Internet.')
            except Exception as exc:
                emit('error','Lecture ElevenLabs : '+str(exc))
        threading.Thread(target=run, daemon=True).start()

    def install(self, source, target):
        available = {(p['from_code'], p['to_code']): p for p in self.catalog}
        pairs = [(source, target)] if (source, target) in available else [(source, 'en'), ('en', target)]
        pairs = [p for p in pairs if p[0] != p[1] and p not in self.engine.packages()]
        for a, b in pairs:
            if (a, b) not in available:
                raise ValueError('Cette paire n’est pas disponible dans le catalogue.')
            package = available[(a, b)]
            url = next(u for u in package['links'] if u.startswith('https://'))
            folder = DATA/'models'
            folder.mkdir(exist_ok=True)
            archive = folder / f'{a}-{b}.download'
            emit('phase', f'Téléchargement du modèle {a.upper()} → {b.upper()}…')
            try:
                with urllib.request.urlopen(url, timeout=60) as response, archive.open('wb') as out:
                    total = int(response.headers.get('Content-Length', 0))
                    received, last = 0, 0
                    while data := response.read(1024*512):
                        out.write(data)
                        received += len(data)
                        if time.monotonic()-last > .25:
                            emit('download', dict(pair=f'{a} → {b}', received=received, total=total))
                            last = time.monotonic()
                with zipfile.ZipFile(archive) as z:
                    # Install metadata last so an interrupted install is not advertised as ready.
                    members = sorted(z.infolist(), key=lambda f:f.filename.endswith('metadata.json'))
                    for member in members:
                        target_path = (folder/member.filename).resolve()
                        if not target_path.is_relative_to(folder.resolve()):
                            raise ValueError('Archive de modèle invalide.')
                        z.extract(member, folder)
            finally:
                archive.unlink(missing_ok=True)
        emit('phase', 'Modèles installés. La traduction fonctionne hors connexion.')

    def close(self):
        self.closed = True
        if self.timer:
            self.timer.cancel()
        if self.stream:
            self.stream.abort()
            self.stream.close()
        self.stop_speech()
        self.vr.close()
        self.pool.shutdown(wait=False, cancel_futures=True)

def main():
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stdin.reconfigure(encoding='utf-8')
    service = Service()
    emit('ready', service.status())
    try:
        for line in sys.stdin:
            message = {}
            try:
                message = json.loads(line)
                result = service.dispatch(message['op'], message.get('args') or {})
                output({'id': message['id'], 'result': result})
            except Exception as exc:
                output({'id': message.get('id'), 'error': str(exc)})
    finally:
        service.close()

if __name__ == '__main__':
    main()
